CREATE TABLE proyecto(
	codigo char(5) primary key not null,
	denominacion varchar(100),
	tipo char(15) check(tipo in ('ERP','Web','Venta_almacen')),
	desc_txt text,
	desc_doc bytea,
	monto_acumulado money,
	url varchar(100)
);

CREATE TABLE cliente(
	dui char(10) primary key not null,
	denominacion varchar(100),
	tipo char(25) check(tipo in ('Persona física','Empresa','ONG','Institución pública','Institución académica'))
);

CREATE TABLE departamento(
	denominacion varchar(100) primary key not null,
	dui_miembro_representante char(10) --FK_Miembro_DUI	
);

CREATE TABLE version(
	codigo_proyecto char(5), --FK_Proyecto_Codigo Primary key
	numero numeric(4,2) not null
);

CREATE TABLE superpachanga(
	nombre varchar(50) primary key not null,
	lema varchar(50),
	annio smallint unique not null check (annio between 2015 and 2100)
);

CREATE TABLE miembro(
	dui char(10) primary key not null,
	nombre varchar(50),
	denominacion_departamento varchar(100) not null --FK_Departamento_denominacion
);

CREATE TABLE asiste(
	nombre_superpachanga varchar(50) not null, --Primary key FK_Superpachanga_nombre,
	dui_miembro char(10) not null --Primary key FK_Miembro_DUI
);

CREATE TABLE proyecto_parte(
	codigo_macroproyecto char(5) not null, --Primary key FK_Proyecto_codigo
	codigo_microproyecto char(5) not null --Primary key FK_Proyecto_codigo
);

CREATE TABLE presenta(
	codigo_proyecto char(5) not null, --Primary key FK_Proyecto_codigo
	nombre_superpachanga varchar(50) not null, --Primary key FK_Superpachanga_nombre
	dui_miembro char(10) --FK_Miembro_DUI
);

CREATE TABLE web(
	codigo_proyecto char(5) not null, --Primary key FK_Proyecto_codigo
	url varchar(100),
	num_tablas int check(num_tablas > 0),
	num_pantallas int check(num_pantallas > 0)

);

CREATE TABLE venta_almacen(
	codigo_proyecto char(5) not null, --Primary key FK_Proyecto_codigo
	num_clientes int check(num_clientes > 0)
);

CREATE TABLE erp(
	codigo_proyecto char(5) not null --Primary key FK_Proyecto_codigo
);

CREATE TABLE ingenieria(
	dui_miembro char(10) not null --Primary key FK_Miemnro_DUI
);

CREATE TABLE gestion(
	dui_miembro char(10) not null --Primary key FK_Miemnro_DUI	
);

CREATE TABLE ventas(
	dui_miembro char(10) not null --Primary key FK_Miemnro_DUI
);

CREATE TABLE desarrolla(
	codigo_proyecto char(5) not null, --Primary key FK_Proyecto_codigo
	dui_miembro_ingenieria char(10) not null, --Primary key FK_Miembro_ingenieria_DUI
	labor text
);

CREATE TABLE modulo_erp(
	codigo_proyecto_erp char(5) not null, --Primary key FK_Proyecto_erp_codigo
	numero numeric(4,2) not null, --Primary key
	descripcion varchar(100) not null --Primary key
);

CREATE TABLE contrata(
	codigo_proyecto char(5) not null, --Primary key FK_Proyecto_codigo
	dui_cliente char(10) not null, --Primary key FK_CLiente_DUI
	dui_miembro_gestion char(10), --FK_Miembro_gestion_DUI
	descuento int,
	implantacion_fecha_inicio date,
	implantacion_precio money,
	mantenimiento_periodicidad char(10) check(mantenimiento_periodicidad in ('Mensual','Bimestral','Trimestral','Cuatrimestral','Semestral','Anual')),
	mantenimiento_precio money
);

CREATE TABLE atiende(
	codigo_proyecto char(5) not null, --Primary key FK_Proyecto_codigo
	dui_cliente char(10) not null, --Primary key FK_Cliente_DUI
	dui_miembro_ventas char(10) not null --Primary key FK_Miembro_ventas_DUI
);

--Departmento FK's
ALTER TABLE departamento
ADD CONSTRAINT FK_Miembro_DUI
FOREIGN KEY (dui_miembro_representante) REFERENCES miembro(dui) ON DELETE CASCADE ON UPDATE CASCADE; --on delete restrict on update cascade deferrable;
--Version FK's
ALTER TABLE version
ADD CONSTRAINT PK_version
PRIMARY KEY (numero, codigo_proyecto);
ALTER TABLE version
ADD CONSTRAINT FK_Proyecto_Codigo
FOREIGN KEY (codigo_proyecto) REFERENCES proyecto(codigo) ON DELETE CASCADE ON UPDATE CASCADE;
--Miembro FK's
ALTER TABLE miembro
ADD CONSTRAINT fk_miembro_departamento
FOREIGN KEY (denominacion_departamento) REFERENCES departamento(denominacion) ON DELETE RESTRICT ON UPDATE CASCADE DEFERRABLE;
--Asiste PK'S FK's
ALTER TABLE asiste
ADD CONSTRAINT PK_asiste
PRIMARY KEY (nombre_superpachanga, dui_miembro);

ALTER TABLE asiste
ADD CONSTRAINT FK_Superpachanga_Nombre
FOREIGN KEY (nombre_superpachanga) REFERENCES superpachanga(nombre) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE asiste
ADD CONSTRAINT FK_Miembro_DUI
FOREIGN KEY (dui_miembro) REFERENCES miembro(dui) ON DELETE CASCADE ON UPDATE CASCADE;
--Proyecto_parte PK'S FK'S
ALTER TABLE proyecto_parte
ADD CONSTRAINT PK_proyecto_parte
PRIMARY KEY (codigo_macroproyecto, codigo_microproyecto);

ALTER TABLE proyecto_parte
ADD CONSTRAINT FK_Macroproyecto_Codigo
FOREIGN KEY (codigo_macroproyecto) REFERENCES proyecto(codigo) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE proyecto_parte
ADD CONSTRAINT FK_Microproyecto_Codigo
FOREIGN KEY (codigo_microproyecto) REFERENCES proyecto(codigo) ON DELETE CASCADE ON UPDATE CASCADE;
--Presenta PK'S FK'S
ALTER TABLE presenta
ADD CONSTRAINT PK_presenta
PRIMARY KEY (codigo_proyecto, nombre_superpachanga);

ALTER TABLE presenta
ADD CONSTRAINT FK_Proyecto_Codigo
FOREIGN KEY (codigo_proyecto) REFERENCES proyecto(codigo) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE presenta
ADD CONSTRAINT FK_Superpachanga_Nombre
FOREIGN KEY (nombre_superpachanga) REFERENCES superpachanga(nombre) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE presenta
ADD CONSTRAINT FK_Miembro_DUI
FOREIGN KEY (dui_miembro) REFERENCES miembro(dui) ON DELETE CASCADE ON UPDATE CASCADE;
--Web PK'S FK'S
ALTER TABLE web
ADD CONSTRAINT PK_web
PRIMARY KEY (codigo_proyecto);
ALTER TABLE web
ADD CONSTRAINT FK_Proyecto_Codigo
FOREIGN KEY (codigo_proyecto) REFERENCES proyecto(codigo) ON DELETE CASCADE ON UPDATE CASCADE;
--Venta-almacen PK'S FK'S
ALTER TABLE venta_almacen
ADD CONSTRAINT PK_venta_almacen
PRIMARY KEY (codigo_proyecto);
ALTER TABLE venta_almacen
ADD CONSTRAINT FK_Proyecto_Codigo
FOREIGN KEY (codigo_proyecto) REFERENCES proyecto(codigo) ON DELETE CASCADE ON UPDATE CASCADE;
--ERP PK'S FK'S
ALTER TABLE erp
ADD CONSTRAINT PK_erp
PRIMARY KEY (codigo_proyecto);
ALTER TABLE erp
ADD CONSTRAINT FK_Proyecto_Codigo
FOREIGN KEY (codigo_proyecto) REFERENCES proyecto(codigo) ON DELETE CASCADE ON UPDATE CASCADE;
--Ingenieria PK'S FK'S
ALTER TABLE ingenieria
ADD CONSTRAINT PK_ingenieria
PRIMARY KEY (dui_miembro);
ALTER TABLE ingenieria
ADD CONSTRAINT FK_Miembro_DUI
FOREIGN KEY (dui_miembro) REFERENCES miembro(dui) ON DELETE CASCADE ON UPDATE CASCADE;
--Gestion PK'S FK'S
ALTER TABLE gestion
ADD CONSTRAINT PK_gestion
PRIMARY KEY (dui_miembro);
ALTER TABLE gestion
ADD CONSTRAINT FK_Miembro_DUI
FOREIGN KEY (dui_miembro) REFERENCES miembro(dui) ON DELETE CASCADE ON UPDATE CASCADE;
--Ventas PK'S FK'S
ALTER TABLE ventas
ADD CONSTRAINT PK_ventas
PRIMARY KEY (dui_miembro);
ALTER TABLE ventas
ADD CONSTRAINT FK_Miembro_DUI
FOREIGN KEY (dui_miembro) REFERENCES miembro(dui) ON DELETE CASCADE ON UPDATE CASCADE;
--Desarrolla PK'S FK'S
ALTER TABLE desarrolla
ADD CONSTRAINT PK_desarrolla
PRIMARY KEY (codigo_proyecto, dui_miembro_ingenieria);

ALTER TABLE desarrolla
ADD CONSTRAINT FK_Proyecto_Codigo
FOREIGN KEY (codigo_proyecto) REFERENCES proyecto(codigo) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE desarrolla
ADD CONSTRAINT FK_Miembro_Ingenieria_DUI
FOREIGN KEY (dui_miembro_ingenieria) REFERENCES ingenieria(dui_miembro) ON DELETE CASCADE ON UPDATE CASCADE;
--Modulo_ERP PK'S FK'S
ALTER TABLE modulo_erp
ADD CONSTRAINT PK_modulo_erp
PRIMARY KEY (codigo_proyecto_erp, numero, descripcion);

ALTER TABLE modulo_erp
ADD CONSTRAINT FK_Proyecto_ERP_Codigo
FOREIGN KEY (codigo_proyecto_erp) REFERENCES erp(codigo_proyecto) ON DELETE CASCADE ON UPDATE CASCADE;
--Contrata PK'S FK'S
ALTER TABLE contrata
ADD CONSTRAINT PK_contrata
PRIMARY KEY (codigo_proyecto, dui_cliente);

ALTER TABLE contrata
ADD CONSTRAINT FK_Proyecto_Codigo
FOREIGN KEY (codigo_proyecto) REFERENCES proyecto(codigo) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE contrata
ADD CONSTRAINT FK_Cliente_DUI
FOREIGN KEY (dui_cliente) REFERENCES cliente(dui) ON DELETE CASCADE ON UPDATE CASCADE;
--Atiende PK'S FK'S
ALTER TABLE atiende
ADD CONSTRAINT PK_atiende
PRIMARY KEY (codigo_proyecto, dui_cliente, dui_miembro_ventas);

ALTER TABLE atiende
ADD CONSTRAINT FK_Proyecto_Codigo
FOREIGN KEY (codigo_proyecto) REFERENCES proyecto(codigo) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE atiende
ADD CONSTRAINT FK_DUI_Cliente
FOREIGN KEY (dui_cliente) REFERENCES cliente(dui) ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE atiende
ADD CONSTRAINT FK_Miembro_Ventas_dui
FOREIGN KEY (dui_miembro_ventas) REFERENCES ventas(dui_miembro) ON DELETE CASCADE ON UPDATE CASCADE;















