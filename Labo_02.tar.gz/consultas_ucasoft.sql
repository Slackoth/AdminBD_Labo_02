SELECT * FROM miembro;
SELECT * FROM superpachanga;
SELECT * FROM asiste;
SELECT * FROM presenta;
SELECT * FROM proyecto;
SELECT * FROM version;
SELECT * FROM contrata;
SELECT * FROM cliente;

--Ej 1:
SELECT m.dui, m.nombre, m.denominacion_departamento
FROM miembro m INNER JOIN asiste a
ON a.dui_miembro = m.dui INNER JOIN superpachanga s 
ON a.nombre_superpachanga = s.nombre
WHERE s.annio = 2018;

--Ej 2:
--Encontrando el maximo
SELECT MAX(p.monto_acumulado)
FROM proyecto p;
--Encontrando el minimo
SELECT MIN(p.monto_acumulado)
FROM proyecto p;
--Proyecto con mayor dinero acumulado
SELECT p.codigo, p.denominacion, p.tipo, p.monto_acumulado
FROM proyecto p
WHERE p.monto_acumulado = (
SELECT MAX(p.monto_acumulado)
FROM proyecto p);
--Proyecto con menor dinero acumulado
SELECT p.codigo, p.denominacion, p.tipo, p.monto_acumulado
FROM proyecto p
WHERE p.monto_acumulado = (
SELECT MIN(p.monto_acumulado)
FROM proyecto p);

--Ej 3:
SELECT EXTRACT(YEAR FROM c.implantacion_fecha_inicio), SUM(c.implantacion_precio)
FROM contrata c
GROUP BY EXTRACT(YEAR FROM c.implantacion_fecha_inicio);

--Ej 4:
SELECT cl.dui, cl.denominacion, cl.tipo, SUM(c.implantacion_precio)
FROM contrata c INNER JOIN cliente cl
ON c.dui_cliente = cl.dui
GROUP BY cl.dui, cl.denominacion, cl.tipo
ORDER BY SUM(c.implantacion_precio) DESC;

--Ej 5:
SELECT p.tipo as tipo_proyecto, SUM(p.monto_acumulado) as monto_acumulado
FROM proyecto p
GROUP BY p.tipo;

--Ej 6:
SELECT p.tipo as tipo_proyecto, SUM(p.monto_acumulado) as monto_acumulado
FROM proyecto p 
GROUP BY p.tipo
HAVING SUM(p.monto_acumulado) > CAST(100000 AS MONEY);

--Ej 7:
SELECT pr.codigo, s.nombre
FROM presenta p INNER JOIN superpachanga s
ON p.nombre_superpachanga = s.nombre RIGHT JOIN proyecto pr 
ON p.codigo_proyecto = pr.codigo;

--Ej 8:
SELECT p.codigo, p.denominacion, p.tipo
FROM proyecto p INNER JOIN version v
ON p.codigo = v.codigo_proyecto
WHERE v.numero > 1.0
GROUP BY p.codigo, p.denominacion, p.tipo
ORDER BY p.codigo ASC;

--Ej 9:
SELECT * FROM proyecto_parte;
SELECT p.codigo as microproyecto,  p.denominacion as micro_denominacion, pp.codigo_macroproyecto as macroproyecto
FROM proyecto p INNER JOIN proyecto_parte pp
ON p.codigo = pp.codigo_microproyecto
WHERE p.denominacion = 'aulavirt';

--Ej 10:
SELECT p.codigo as microproyecto,  p.denominacion as micro_denominacion, pp.codigo_macroproyecto as macroproyecto
FROM proyecto p INNER JOIN proyecto_parte pp
ON p.codigo = pp.codigo_microproyecto;
